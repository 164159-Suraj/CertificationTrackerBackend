package com.ct.CertificateTracker.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ct.CertificateTracker.model.voucherInfo;

public interface VoucherInfoRepo extends MongoRepository<voucherInfo, String> {

}
