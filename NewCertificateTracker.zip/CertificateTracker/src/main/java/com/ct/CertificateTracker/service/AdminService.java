package com.ct.CertificateTracker.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.CertificateTracker.model.Admin;
import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.CoreCertificationDetails;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.model.PlannedCertification;
import com.ct.CertificateTracker.model.Tower;
import com.ct.CertificateTracker.model.voucher;
import com.ct.CertificateTracker.model.voucherInfo;
import com.ct.CertificateTracker.repository.AdminRepo;
import com.ct.CertificateTracker.repository.CertifiacationDetailsRepo;
import com.ct.CertificateTracker.repository.CertificateRepo;
import com.ct.CertificateTracker.repository.EmployeeRepo;
import com.ct.CertificateTracker.repository.PlannedCerRepo;
import com.ct.CertificateTracker.repository.VoucherInfoRepo;
import com.ct.CertificateTracker.repository.VoucherRepo;

@Service
public class AdminService {
	
	@Autowired
	private EmployeeRepo empRepository;
	
	@Autowired
	private CertificateRepo certificateRepo;
	
	@Autowired
	private CertifiacationDetailsRepo detailsRepo;
	
	@Autowired
	private AdminRepo adminRepo;
	
	@Autowired
	private VoucherRepo voucherRepo;
	
	@Autowired
	private VoucherInfoRepo voucherInfoRepo;
	
	
	@Autowired
	private PlannedCerRepo plannedCerRepo;
	
	public List<Tower> getTowers() {
		System.out.println("in admin service\\n\n\n\n");
		List<Employee> temp= empRepository.findAll();
		  Map<String, List<Employee>> groupByTower = 
					temp.stream().collect(Collectors.groupingBy(Employee::getGlobalPractice));
                 // System.out.println("details"+groupByTower.keySet());
		        
		  
		  
		  
		  Set set=groupByTower.entrySet();//Co enverting to Set so that we can traverse  
		    Iterator itr=set.iterator(); 
		    List<Tower> towers=new ArrayList<>();
		    while(itr.hasNext()){  
		    	Tower tower=new Tower();
		        //Converting to Map.Entry so that we can get key and value separately  
		    	Map.Entry entry=(Map.Entry)itr.next();  
		        tower.setTowerName((String)entry.getKey());
		        tower.setEmplist((List<Employee>) entry.getValue());
		        towers.add(tower);
		        
		        
		    }
		    
		    List<Certificate> allCertificates=certificateRepo.findAll();
		    List<CoreCertificationDetails> coreDetails=detailsRepo.findAll();
		    System.out.println(allCertificates);
		    for(Tower t:towers) {
		    	int count=0,ccount=0;
		    	
		    	List<Employee> employees=t.getEmplist();
		    	
		    	for(Employee e:employees)
		    	{	
		    		boolean havingCertification=false, havingCoreCertification=false;
		    	     for(Certificate c:allCertificates) {
		    	    	 if(e.getEmpId().equals((c.getEmpId()))) {
		    	    		 havingCertification=true;
		    	    		 for(CoreCertificationDetails cd:coreDetails)
		    	    		 {
		    	    			 if(c.getCerName().equalsIgnoreCase(cd.getCertificationName()))
		    	    			 {
		    	    				 if(cd.getCoreCeritification().equalsIgnoreCase("yes")) 
		    	    				 {
		    	    					 havingCoreCertification=true;
		    	    					 break;
		    	    				 }
		    	    			 }
		    	    		 }
		    	    		  
		    	    		 
		    	    	 }
		    	    		 
		    	    	 }
		    	     if(havingCertification)
		    	    	 count++;
		    	     if(havingCoreCertification)
		    	    	 ccount++;
		    	     }
		    	t.setTotalEmp(employees.size());
		    	t.setCertifiedEmp(count);
		    	t.setCoreCertified(ccount);
		    	t.setNonCoreCertified(count-ccount);
		    	double y=(((double)t.getCoreCertified()/t.getTotalEmp())*100);
		    	t.setCorePercentage((double)Math.round(y));
		    	double x=(((double)t.getCertifiedEmp()/t.getTotalEmp())*100);
		    	
		    	 t.setPercentage((double) Math.round(x));
		      
		    }
		    
		    
		    
		    
		    for(Tower t:towers) {
		    	System.out.println(t.getTowerName()+"  "+t.getTotalEmp()+"   "+t.getCertifiedEmp()+"    "+t.getCoreCertified()+"  "+t.getNonCoreCertified()+"   "+t.getPercentage()+"   "+t.getCorePercentage());
		    }
		    
		   
		    
		    
		    
		    return towers;
		        
	}
	
	
	
	public List<CoreCertificationDetails> getCertificateDetails(){
		return detailsRepo.findAll();
		
	}
	
	public CoreCertificationDetails addnewCertificate(CoreCertificationDetails c) {
		List<CoreCertificationDetails> allCer=detailsRepo.findAll();
		boolean existed=false;
		for(CoreCertificationDetails cer:allCer) {
			if((cer.getCertificationCategory().equalsIgnoreCase(c.getCertificationCategory()))&&(cer.getCertificationName().equalsIgnoreCase(c.getCertificationName()))) {
				existed=true;
			}
			
		}
		
		if(existed)
			return null;
		else
		return detailsRepo.save(c);
		
		
	}
	
	public Admin loginValidate(Admin admin) {
		Optional<Admin> available=adminRepo.findById(admin.getEmpId());
		if(available.isPresent()) {
			Admin isThere= available.get();
			if(isThere.getPassword().equals(admin.getPassword())){
				return isThere;
			}
		}
		
		return null;
		
		
	}
	
	public Admin register(Admin admin) {
		return adminRepo.save(admin);
		
	}
   
	public List<voucherInfo> getVoucherInfo(){
		List<voucher> allVouchers=voucherRepo.findAll();
		
		Map<String, List<voucher>> groupByCertificationName = allVouchers.stream().collect(
				Collectors.groupingBy(voucher::getExamName));
		// System.out.println("details"+groupByTower.keySet());

		Set set = groupByCertificationName.entrySet();
		
		Iterator itr = set.iterator();
		List<voucherInfo> displayedVouchers=new ArrayList<voucherInfo>();
		
		while (itr.hasNext()) {
			Map.Entry entry = (Map.Entry) itr.next();
			voucherInfo voucherInfo=new voucherInfo();
			voucherInfo.setCertificationName((String)entry.getKey());
			List<voucher> vo=(List<voucher>)entry.getValue(); 
			int availableCount=0,blockedCount=0,utilizedCount=0,expiredCount=0,totalCount=0;
			String stream=null;
			
			for(voucher v:vo){
				stream=v.getStream();
				if(v.getStatus().equalsIgnoreCase("Available"))
						availableCount++;
				else if(v.getStatus().equalsIgnoreCase("Blocked"))
					blockedCount++;
				else if(v.getStatus().equalsIgnoreCase("Utilized"))
					utilizedCount++;
				else if(v.getStatus().equalsIgnoreCase("Expired"))
					expiredCount++;
				
				totalCount++;
			}
			
			voucherInfo.setStream(stream);
			voucherInfo.setBlockedCount(blockedCount);
			voucherInfo.setTotalVouchers(totalCount);
			voucherInfo.setUtilizedCount(utilizedCount);
			voucherInfo.setExpiredCount(expiredCount);
			voucherInfo.setAvailableCount(availableCount);
			
			
			displayedVouchers.add(voucherInfo);
			
			
			
			 
				
			}
		
		/*for(VoucherInfo v:displayedVouchers)
		System.out.println(v);
		return null;
		*/	
			
		return displayedVouchers;
				
	}



	public List<voucher> getVoucher() {
		
		return voucherRepo.findAll();
	}
	
	public List<PlannedCertification> getVoucherRequestedList(){
		List<PlannedCertification> allCer=plannedCerRepo.findAll();
		List<PlannedCertification> requestedCer=new ArrayList<PlannedCertification>();
		
		for(PlannedCertification p:allCer){
			if(p.getVoucherStatus().contentEquals("Requested")){
				requestedCer.add(p);
			}
		}
		
		return requestedCer;
		
		
		
	}
	
	public PlannedCertification checkVoucherAvailability(PlannedCertification pC){
		List<voucher> allVoucher=voucherRepo.findAll();
		
		for(voucher v:allVoucher){
			if(v.getExamName().contentEquals(pC.getExamName()) &&(v.getStatus().contentEquals("Available"))){
				v.setEmpId(pC.getEmpID());
				v.setEmpName(pC.getEmpName());
				v.setStatus("Blocked");
				
				
				pC.setVoucherStatus("Assigned");
				pC.setVoucherCode(v.getVoucherCode());
				
				voucherRepo.save(v);
				plannedCerRepo.save(pC);
				break;
				
			}
			
		}
		
		return pC;
		
		
	}

}
