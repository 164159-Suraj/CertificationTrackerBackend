package com.ct.CertificateTracker.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.CoreCertificationDetails;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.model.PlannedCertification;
import com.ct.CertificateTracker.repository.CertifiacationDetailsRepo;
import com.ct.CertificateTracker.repository.CertificateRepo;
import com.ct.CertificateTracker.repository.EmployeeRepo;
import com.ct.CertificateTracker.repository.PlannedCerRepo;



@Service
public class EmployeeService {
	
	
	@Autowired 
	private EmployeeRepo empRepository;
	
	@Autowired
	private CertificateRepo certificateRepo;
	
	@Autowired
	private CertifiacationDetailsRepo certifiacationDetailsRepo;
	
	@Autowired
	private PlannedCerRepo plannedCerRepo;
	
	
	public List<Certificate> getCertificates(Integer currentUserId){
		List<Certificate> allCertificates=certificateRepo.findAll();
		List<Certificate> empCertificates=new ArrayList<Certificate>();
		
		
		for(Certificate c:allCertificates) {
			if(c.getEmpId().equals(currentUserId)) {
				empCertificates.add(c);
			}
		}
		
		
		return empCertificates;
		
	}
	
	public Certificate addCertificate(Certificate certificate){
		return certificateRepo.save(certificate);
		
		
	}
	public Certificate updatecertificate(Certificate certificate) {
		List<Certificate> allCertifiactes=certificateRepo.findAll();
		 for(Certificate c:allCertifiactes)
		 {
			 if((c.getEmpId().equals(certificate.getEmpId()))&&(c.getCerName().equals(certificate.getCerName())))
			{
				 certificate.setId(c.getId());
			 }
					 
		
	     }
		 return certificateRepo.save(certificate);
		 
		 
	}
		 
		 
		 
	 public Set<String> getCerCatigory(){
			 List<CoreCertificationDetails> cerValues=certifiacationDetailsRepo.findAll();
			 Set<String> collect = cerValues.stream().map(x -> x.getCertificationCategory()).collect(Collectors.toSet());
			 return collect;
			 
			 
		 }
	 
	 
	 public List<String> getCertificatesOfCategory(String category){
		 List<CoreCertificationDetails> allCer=certifiacationDetailsRepo.findAll();
		 List<String> certificates=new ArrayList<String>();
		 for(CoreCertificationDetails c:allCer) {
			 if(c.getCertificationCategory().equalsIgnoreCase(category))
				 certificates.add(c.getCertificationName());

		 }
		 
		 return certificates;
		 
		 
	 }
	 
	 public List<PlannedCertification> getPlannedCertificates(String empId){
		 System.out.println(empId);
		 List<PlannedCertification> allCer=plannedCerRepo.findAll();
		 System.out.println(allCer);
		 List<PlannedCertification> plannedCertifications=new ArrayList<PlannedCertification>();
		 for(PlannedCertification pC:allCer) {
			 System.out.println(pC.getEmpID());
			 if(pC.getEmpID().contentEquals(empId))
				 plannedCertifications.add(pC);
		 }
		 
		 return plannedCertifications;
		 
		 
	 }
		 public PlannedCertification savePlannedCertificate(PlannedCertification certification){
			 return plannedCerRepo.save(certification);
			 
		 }
		 
		 

		 public PlannedCertification insertMarks(PlannedCertification certification){
			 
			 List<PlannedCertification> allCer=plannedCerRepo.findAll();
			 System.out.println(allCer);
			
			 for(PlannedCertification pc:allCer) {
				
				 if(pc.getEmpID().contentEquals(certification.getEmpID())&&pc.getExamName().contentEquals(certification.getExamName()))
					 certification.set_id(pc.get_id());
				 
			 }
			 
			 return plannedCerRepo.save(certification);
			 
			 
		 }
		 
		 
		 
		 public PlannedCertification requestingVoucher(PlannedCertification pC){
			 List<PlannedCertification> allCer=plannedCerRepo.findAll();
			 
			 for(PlannedCertification p:allCer){
				 if(p.getEmpID().contentEquals(pC.getEmpID()) && p.getEmpID().contentEquals(pC.getEmpID())){
					 pC.set_id(p.get_id());
					 pC.setVoucherStatus("Requested");
				 }

			 }
			 
			 return plannedCerRepo.save(pC);
			 
			 
		 }
			 
		 }
	
	
	
		
